import os, numpy as np, mlflow, mlflow.sklearn, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
def main():
    data_dir = "thyroid_preprocessing"
    X_train = np.load(os.path.join(data_dir, "X_train.npy"))
    y_train = np.load(os.path.join(data_dir, "y_train.npy"), allow_pickle=True)
    X_test = np.load(os.path.join(data_dir, "X_test.npy"))
    y_test = np.load(os.path.join(data_dir, "y_test.npy"), allow_pickle=True)
    mlflow.set_tracking_uri("http://127.0.0.1:5005")
    mlflow.set_experiment("Thyroid Disease Submission")
    with mlflow.start_run():
        mlflow.autolog()
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        acc = accuracy_score(y_test, model.predict(X_test))
        print(f"Accuracy: {acc:.4f}")
        joblib.dump(model, "best_thyroid_model.pkl")
if __name__ == "__main__": main()
