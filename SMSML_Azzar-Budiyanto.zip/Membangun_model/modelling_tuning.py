import os
import numpy as np
import mlflow
import mlflow.sklearn
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

def main():
    # Menggunakan path relatif yang benar untuk dataset prapemrosesan
    data_dir = "thyroid_preprocessing"
    if not os.path.exists(data_dir):
        data_dir = "preprocessing/thyroid_preprocessing"
        
    X_train = np.load(os.path.join(data_dir, "X_train.npy"))
    y_train = np.load(os.path.join(data_dir, "y_train.npy"), allow_pickle=True)
    X_test = np.load(os.path.join(data_dir, "X_test.npy"))
    y_test = np.load(os.path.join(data_dir, "y_test.npy"), allow_pickle=True)

    mlflow.set_tracking_uri("http://127.0.0.1:5025")
    mlflow.set_experiment("Thyroid Tuning")

    param_grid = {
        "n_estimators": [50, 100],
        "max_depth": [5, 10, None]
    }

    with mlflow.start_run(run_name="RandomForest_Manual_Logging"):
        # Hyperparameter Tuning
        gs = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=3)
        gs.fit(X_train, y_train)
        
        best_model = gs.best_estimator_
        y_pred = best_model.predict(X_test)
        
        # Manual Logging Parameter
        mlflow.log_params(gs.best_params_)
        
        # Manual Logging Metriks (Menyamai autolog)
        acc = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='weighted')
        prec = precision_score(y_test, y_pred, average='weighted')
        rec = recall_score(y_test, y_pred, average='weighted')
        
        mlflow.log_metric("accuracy", acc)
        mlflow.log_metric("f1_score", f1)
        mlflow.log_metric("precision", prec)
        mlflow.log_metric("recall", rec)
        mlflow.log_metric("best_cv_score", gs.best_score_)
        
        # Manual Logging Model
        mlflow.sklearn.log_model(best_model, "model")
        
        # Simpan model secara lokal untuk kebutuhan serving
        os.makedirs("Membangun_model", exist_ok=True)
        joblib.dump(best_model, "Membangun_model/best_thyroid_model.pkl")
        
        print(f"Model berhasil dilatih secara manual dengan Accuracy: {acc:.4f}")

if __name__ == "__main__":
    main()
