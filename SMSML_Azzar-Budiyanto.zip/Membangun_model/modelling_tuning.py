import os, numpy as np, mlflow, mlflow.sklearn, joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
def main():
    data_dir = "thyroid_preprocessing"
    X_train = np.load(os.path.join(data_dir, "X_train.npy"))
    y_train = np.load(os.path.join(data_dir, "y_train.npy"), allow_pickle=True)
    X_test = np.load(os.path.join(data_dir, "X_test.npy"))
    y_test = np.load(os.path.join(data_dir, "y_test.npy"), allow_pickle=True)
    mlflow.set_tracking_uri("http://127.0.0.1:5005")
    mlflow.set_experiment("Thyroid Tuning")
    with mlflow.start_run(run_name="RandomForest_Tuning"):
        param_grid = {"n_estimators": [50, 100], "max_depth": [5, 10, None]}
        gs = GridSearchCV(RandomForestClassifier(random_state=42), param_grid, cv=3)
        gs.fit(X_train, y_train)
        best = gs.best_estimator_
        mlflow.log_params(gs.best_params_)
        mlflow.log_metric("accuracy", accuracy_score(y_test, best.predict(X_test)))
        mlflow.sklearn.log_model(best, "model")
        joblib.dump(best, "best_thyroid_model.pkl")
if __name__ == "__main__": main()
