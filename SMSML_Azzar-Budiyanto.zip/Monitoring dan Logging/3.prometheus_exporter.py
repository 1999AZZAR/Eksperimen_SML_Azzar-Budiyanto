from flask import Flask, request, jsonify, Response
import time, joblib, numpy as np, psutil, os
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
app = Flask(__name__)
R_COUNT = Counter("http_requests_total", "Total Requests")
THROUGHPUT = Counter("http_requests_throughput", "Throughput")
LATENCY = Histogram("http_request_duration_seconds", "Latency")
PRED_COUNT = Counter("model_predictions_total", "Predictions", ["result"])
CPU = Gauge("system_cpu_usage", "CPU")
RAM = Gauge("system_ram_usage", "RAM")

MODEL_PATH = "Membangun_model/best_thyroid_model.pkl"
SCALER_PATH = "preprocessing/thyroid_preprocessing/scaler.pkl"

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

@app.route("/predict", methods=["POST"])
def predict():
    start = time.time()
    R_COUNT.inc()
    THROUGHPUT.inc()
    try:
        data = request.get_json()
        feat = np.array(data["features"]).reshape(1, -1)
        pred = model.predict(scaler.transform(feat))[0]
        LATENCY.observe(time.time() - start)
        PRED_COUNT.labels(result=str(pred)).inc()
        return jsonify({"prediction": int(pred), "status": "success"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/metrics")
def metrics():
    CPU.set(psutil.cpu_percent())
    RAM.set(psutil.virtual_memory().percent)
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
