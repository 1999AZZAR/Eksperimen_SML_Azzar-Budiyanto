import requests, time, numpy as np, os
url = "http://127.0.0.1:8000/predict"
for i in range(5):
    try: requests.post(url, json={"features": [41,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1.3,1,2.5,1,125,1,1.14,1,109]}, timeout=2)
    except: pass
    time.sleep(0.5)
